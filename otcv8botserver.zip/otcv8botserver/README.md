# Websocket bot server for otclientv8
## Version: 1.1

### DISCORD: https://discord.gg/feySup6
### Forum: http://otclient.net

Requirements:
- C++17 compiler
- libz-dev
- https://github.com/uNetworking/uWebSockets [18.9.0]
- https://github.com/uNetworking/uSockets [0.5.0]
- https://github.com/nlohmann/json/blob/develop/single_include/nlohmann/json.hpp

### Compilation of required libraries
```
apt install zlib1g-dev build-essential
cd uWebSockets
make
```

### Compilation
```
g++ main.cpp -std=c++17 -Ofast uWebSockets/uSockets/uSockets.a -IuWebSockets/src -IuWebSockets/uSockets/src -lz -lpthread -o botserver
```


### Using it
Edit file `otclientv8/modules/game_bot/functions/server.lua`:
```
context.BotServer.url = "ws://bot.otclient.ovh:8000/"
```
to your server IP or domain.